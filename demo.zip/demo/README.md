# 概要说明
模块内的全部代码放在以模块命名的目录下，按照作用的不同进行分组。如controller包下是当前模块下的所有功能的controller。


# 内容说明
- **bo** 业务对象，service层使用的对象类，与dataobject不会完全一致建议独立定义。
- **controller** controller层代码。一般与do实体类一一对应。特殊功能的controller类可按需创建。
- **dto** 数据传输对象，用于controller层进行数据传输，按需使用。
- **dataobject** 与数据库表结构对应的实体类DO
- **mapper** mybatis mapper类。mapper一般与entity实体类一一对应。对于多表关联的查询，放到主表对应的mapper文件中。
- **service** service层代码，一般与do实体类一一对应，也可按需创建特定场景的service类。

# 其他
- 因时间有限，代码实现考虑不够全面，后续会持续优化。