
package com.rongdan.module.demo.controller.admin;

import com.rongdan.framework.common.pojo.CommonResult;
import com.rongdan.framework.common.pojo.PageParam;
import com.rongdan.framework.common.pojo.PageResult;
import com.rongdan.module.demo.dataobject.DemoUserDo;
import com.rongdan.module.demo.service.DemoUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Arrays;

import static com.rongdan.framework.common.pojo.CommonResult.success;

/**
 * @author xewsk
 * @description: 示例用户管理controller类
 * @date 2023/3/28 21:24
 */
@Tag(name = "示例 - 用户管理")
@RestController
@RequiredArgsConstructor()
@RequestMapping("/demo/user")
public class DemoUserController {
    private final DemoUserService demoUserService;

    @Operation(summary = "获得用户分页")
    @GetMapping("/page" )
    //@PreAuthorize("@ss.hasPermission('demo:user:query')")
    public CommonResult<PageResult<DemoUserDo>> getUserPage(PageParam pageParam, DemoUserDo demoUserDo) {
        PageResult<DemoUserDo> pageResult=demoUserService.getTenantPage(pageParam,demoUserDo);
        return success(pageResult);
    }


    @GetMapping("/get")
    @Operation(summary = "获得用户")
    @Parameter(name = "id", description = "编号", required = true, example = "1024")
    //@PreAuthorize("@ss.hasPermission('demo:user:query')")
    public CommonResult<DemoUserDo> getUserById(@RequestParam("id") Long id) {
        DemoUserDo demoUserDo = demoUserService.selectById(id);
        return success(demoUserDo);
    }

    @PostMapping("/create")
    @Operation(summary = "创建用户")
    @PreAuthorize("@ss.hasPermission('demo:user:create')")
    public CommonResult<Long> save(@Valid @RequestBody DemoUserDo demoUserDo) {
        return success(demoUserService.save(demoUserDo));
    }

    @PutMapping("/update")
    @Operation(summary = "更新用户")
    //@PreAuthorize("@ss.hasPermission('demo:user:update')")
    public CommonResult<Boolean> updateById(@Valid @RequestBody DemoUserDo demoUserDo) {
        return success(demoUserService.updateById(demoUserDo));
    }

    @DeleteMapping("/delete")
    @Operation(summary = "删除用户")
    @Parameter(name = "id", description = "编号", required = true, example = "1024")
    //@PreAuthorize("@ss.hasPermission('demo:user:delete')")
    public CommonResult<Boolean> removeById(@RequestParam("id") Long id) {
        return success(demoUserService.removeById(id));
    }

}
