
package com.rongdan.module.demo.mapper;

import com.rongdan.framework.common.pojo.PageParam;
import com.rongdan.framework.common.pojo.PageResult;
import com.rongdan.framework.mybatis.core.mapper.BaseMapperX;
import com.rongdan.framework.mybatis.core.query.LambdaQueryWrapperX;
import com.rongdan.module.demo.dataobject.DemoUserDo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author xewsk
 * @description: 用户管理Mapper
 * @date 2023/3/28 17:20
 */
@Mapper
public interface DemoUserMapper extends BaseMapperX<DemoUserDo> {
    /**
     * 分页查询用户，支持按昵称模糊查询/用户名查询/备注模糊查询
     * @param pageParam
     * @param user
     * @return
     */
    default PageResult<DemoUserDo> selectPage(PageParam pageParam, DemoUserDo user) {
        return selectPage(pageParam, new LambdaQueryWrapperX<DemoUserDo>()
                .likeIfPresent(DemoUserDo::getNickname, user.getNickname())
                .eqIfPresent(DemoUserDo::getUsername,user.getUsername())
                .likeIfPresent(DemoUserDo::getRemark, user.getRemark()));
    }
}