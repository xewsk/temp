package com.rongdan.module.demo.framework.web.config;

import com.rongdan.framework.swagger.config.RongdanSwaggerAutoConfiguration;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * demo 模块的 web 组件的 Configuration
 *
 * @author
 */
@Configuration(proxyBeanMethods = false)
public class DemoWebConfiguration {

    /**
     * demo 模块的 API 分组
     */
    @Bean
    public GroupedOpenApi demoGroupedOpenApi() {
        return RongdanSwaggerAutoConfiguration.buildGroupedOpenApi("demo");
    }

}
