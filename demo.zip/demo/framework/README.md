- 当前模块中与框架适配相关的内容。

- web/config/DemoWebConfiguration的作用是为当前模块的api创建api分组。