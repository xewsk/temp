
package com.rongdan.module.demo.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.rongdan.framework.common.pojo.PageParam;
import com.rongdan.framework.common.pojo.PageResult;
import com.rongdan.module.demo.dataobject.DemoUserDo;
import com.rongdan.module.demo.mapper.DemoUserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.Serializable;

/**
 * @author xewsk
 * @description: 用户管理服务类
 * @date 2023/3/28 21:20
 */

@Service
@RequiredArgsConstructor
@Slf4j
public class DemoUserService  {

    private final DemoUserMapper demoUserMapper;


    public PageResult<DemoUserDo> getTenantPage(PageParam pageParam, DemoUserDo demoUserDo) {
        return demoUserMapper.selectPage(pageParam,demoUserDo);
    }

    public DemoUserDo selectById(Long id) {
        return demoUserMapper.selectById(id);
    }
    public Long save(DemoUserDo demoUserDo){
         demoUserMapper.insert(demoUserDo);
         return demoUserDo.getId();
    }
    public boolean updateById(DemoUserDo demoUserDo){
        return SqlHelper.retBool(demoUserMapper.updateById(demoUserDo));
    }
    public boolean removeById(Serializable id) {
        return SqlHelper.retBool(demoUserMapper.deleteById(id));
    }
}
