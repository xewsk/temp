/**
 * demo 模块下，示例模块。
 *
 * 1. Controller URL：以 /demo/ 开头，避免和其它 Module 冲突
 * 2. DataObject 表名：以 demo_ 开头，方便在数据库中区分
 */
package com.rongdan.module.demo;
