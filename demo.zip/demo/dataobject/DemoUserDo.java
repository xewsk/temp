
package com.rongdan.module.demo.dataobject;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.rongdan.framework.common.enums.CommonStatusEnum;
import com.rongdan.framework.tenant.core.db.TenantBaseDO;
import com.rongdan.module.system.enums.common.SexEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

/**
 * @author xewsk
 * @description:
 * @date 2023/3/28 16:55
 */
@TableName(value = "demo_user", autoResultMap = true)
@Data
@EqualsAndHashCode(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DemoUserDo extends TenantBaseDO {

    @Schema(description = "用户ID", example = "user")
    @TableId
    private Long id;

    @Schema(description = "用户账号", required = true, example = "融担")
    @NotNull(message = "用户账号不能为空")
    private String username;
    /**
     * 加密后的密码
     *
     * 因为目前使用 {@link BCryptPasswordEncoder} 加密器，所以无需自己处理 salt 盐
     */
    private String password;
    /**
     * 用户昵称
     */
    @Schema(description = "用户昵称")
    @NotNull(message = "用户昵称不能为空")
    private String nickname;
    /**
     * 备注
     */
    @Schema(description = "备注")
    private String remark;
    /**
     * 用户邮箱
     */
    @Schema(description = "用户邮箱")
    private String email;
    /**
     * 手机号码
     */
    @Schema(description = "手机号码")
    private String mobile;
    /**
     * 用户性别
     *
     * 枚举类 {@link SexEnum}
     */
    @Schema(description = "用户性别")
    private Integer sex;
    /**
     * 用户头像
     */
    @Schema(description = "用户头像")
    private String avatar;
    /**
     * 帐号状态
     *
     * 枚举 {@link CommonStatusEnum}
     */
    @Schema(description = "帐号状态")
    @NotNull(message = "用户状态不能为空")
    private Integer status;

    @Schema(description = "最后登录IP")
    private String loginIp;

    @Schema(description = "最后登录时间")
    private LocalDateTime loginDate;
}
